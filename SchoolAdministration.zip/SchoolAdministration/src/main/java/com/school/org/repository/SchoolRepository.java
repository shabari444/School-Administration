package com.school.org.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.school.org.pojos.School;



public interface SchoolRepository extends JpaRepository<School,String> {

}


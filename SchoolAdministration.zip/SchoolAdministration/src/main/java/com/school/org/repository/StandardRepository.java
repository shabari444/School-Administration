package com.school.org.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.school.org.pojos.Standard;

public interface StandardRepository extends JpaRepository<Standard, String> {

}

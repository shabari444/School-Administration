package com.school.org.pojos;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Standard {

	@Id
	private String StandardName;
	private int noOfStudents;

	@ManyToOne
	private School school;

	public String getStandardName() {
		return StandardName;
	}

	public void setStandardName(String StandardName) {
		this.StandardName = StandardName;
	}

	public int getNoOfStudents() {
		return noOfStudents;
	}

	public void setNoOfStudents(int noOfStudents) {
		this.noOfStudents = noOfStudents;
	}

	public School getSchool() {
		return school;
	}

	public void setSchool(School school) {
		this.school = school;
	}

}

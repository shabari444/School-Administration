package com.school.org.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.school.org.pojos.Standard;
import com.school.org.repository.StandardRepository;

@Service
public class StandardService {

	@Autowired
	private StandardRepository standardRepository;

	public List<Standard> getStandards() {

		return standardRepository.findAll();
	}

	public void postStandard(Standard Standard) {
		standardRepository.save(Standard);
	}

	public Optional findStandardById(String id) {
		return standardRepository.findById(id);
	}

	public Standard updateStandard(Standard Standard) {
		return standardRepository.save(Standard);
	}

	public void deleteStandard(String id) {
		standardRepository.deleteById(id);
	}

}

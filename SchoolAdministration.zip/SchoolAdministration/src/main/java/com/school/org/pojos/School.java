package com.school.org.pojos;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class School {

	@Id
	private String schoolID;
	private String schoolName;
	private String schoolCity;

	@OneToMany
	private List<Standard> classes;

	public void setClasses(List<Standard> classes) {
		this.classes = classes;
	}

	public List<Standard> getClasses() {
		return classes;
	}

	public String getSchoolID() {
		return schoolID;
	}

	public void setSchoolID(String schoolID) {
		this.schoolID = schoolID;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getSchoolCity() {
		return schoolCity;
	}

	public void setSchoolCity(String schoolCity) {
		this.schoolCity = schoolCity;
	}

}

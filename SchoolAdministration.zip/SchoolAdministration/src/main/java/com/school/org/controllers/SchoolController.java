package com.school.org.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.school.org.pojos.School;
import com.school.org.services.SchoolService;

@RestController
public class SchoolController {

	@Autowired
	private SchoolService schoolService;

	@GetMapping(value = "/schools")
	public List<School> getSchools() {
		return schoolService.getSchools();
	}

	@PostMapping(value = "/schools")
	public void postSchool(@RequestBody School school) {
         schoolService.postSchool(school);
	}
	
	@PutMapping(value="/schools")
	public School updateSchool(@RequestBody School school) {
		return schoolService.updateSchool(school);
		
	}
	
	@DeleteMapping(value="/schools")
	public void deleteSchool(String id){
		 schoolService.deleteSchool(id);
	}
	
	@GetMapping(value="/schools/{id}")
	public Optional getSchoolById(@PathVariable String id) {
		return schoolService.findSchoolById(id);
	}
}

package com.school.org.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.school.org.pojos.School;
import com.school.org.repository.SchoolRepository;

@Service
public class SchoolService {
	
	@Autowired
	private SchoolRepository schoolRepository;
	
	public List<School> getSchools(){
		
		 return schoolRepository.findAll();
	}
	
	public void postSchool(School school) {
		schoolRepository.save(school);
	}
	
	public Optional findSchoolById(String id) {
		return  schoolRepository.findById(id);
	}
	
	public School updateSchool(School school) {
		return schoolRepository.save(school);
	}
	
	public void deleteSchool(String id) {
		schoolRepository.deleteById(id);
	}

}
